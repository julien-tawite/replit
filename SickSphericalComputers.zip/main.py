# ask for a number
num = int(input("Enter a number: "))

# initialize counter
count = 0 

# multiply through numbers from 0 to 10 with the users number
while (count <= 10):
  print(str(count) + "*" + str(num) + "=" + str(num * count))
  count = count + 1